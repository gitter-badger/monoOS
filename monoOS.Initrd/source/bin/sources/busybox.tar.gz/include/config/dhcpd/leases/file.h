#define CONFIG_DHCPD_LEASES_FILE "/var/lib/misc/udhcpd.leases"
