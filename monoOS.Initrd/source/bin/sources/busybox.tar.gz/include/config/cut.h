#define CONFIG_CUT 1
